<?php
header ( "content-type:text/html;charset=utf-8" );
if (! isset ( $_SESSION )) {
	session_start ();
}
if (! isset ( $_SESSION['userName'] )) {
	header ( "location:login.php" );
} else {
	$id = $_REQUEST['id'];
	require_once '../dbconfig.php';
	// 删除语句
	$sql = "delete from score where id='$id'";
	$sql1 ="SELECT * FROM score WHERE id=".$id; 
	$result1=mysql_query($sql1);
	$row1=mysql_fetch_array($result1);
	$sql2="DELETE FROM answer_paper WHERE studentid='".$row1['studentId']."' AND paper_id=".$row1['paper_id'];
	mysql_query($sql2);
	//exit($sql);
	$result = mysql_query ( $sql, $conn );
	if ($result) {
		header("location:score.php");
	} else {
		echo "<script>alert('删除失败!');</script>";
		echo "<a href='score.php'>返回</a>";
	}
}
?>
