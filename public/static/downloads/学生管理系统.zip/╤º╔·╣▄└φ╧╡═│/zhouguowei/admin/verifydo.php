<?php
require_once '../dbconfig.php';
header ( "content-type:text/html;charset=utf-8" );

// 取表单数据
$id = $_REQUEST ['id'];
$status=$_REQUEST['status'];
// sql语句中字符串数据类型都要加引号，数字字段随便
$sql = "UPDATE user SET status=$status WHERE id=$id";
if($status==1){
if (mysql_query ( $sql )) {
	header("location:index2.php");
} else {
	echo "审核通过失败！！！<br/>";
	echo "<a href='index2.php'>返回</a>";
}
} elseif($status==-1){
    if (mysql_query ( $sql )) {
        header("location:index2.php");
    } else {
        echo "冻结失败！！！<br/>";
        echo "<a href='index2.php'>返回</a>";
    }
} elseif($status==1){
    if (mysql_query ( $sql )) {
        header("location:index2.php");
    } else {
        echo "解冻失败！！！<br/>";
        echo "<a href='index2.php'>返回</a>";
    }
}

