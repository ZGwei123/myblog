<?php
header("content-type:text/html;charset=utf-8");
if (! isset($_SESSION)) {
    session_start();
}
if (! isset($_SESSION['userName'])) {
    header("location:login.php");
} else {
    $oldpassword = sha1($_POST['oldpassword']);
    $password = sha1($_POST['password']);
    $password1 = sha1($_POST['password1']);
    require_once '../dbconfig.php';
    // 取出用户名
    $username = $_SESSION['userName'];
    // 根据用户名和密码去查询帐号表
    $sql = "select * from user where username= '$username' and password='$oldpassword'";
    $result = mysql_query($sql, $conn);
    if ($row = mysql_fetch_array($result)) {
        $id = $row['id'];
        // 修改密码
        if ($password == $password1) {
            $query = "UPDATE user SET password='$password' WHERE id='$id'";
            $result = mysql_query($query, $conn);
            if ($result) {
                header('location:loginout.php');
            } else {
                echo "<script>alert('密码修改失败!');</script>";
                echo "密码修改失败!<br/>";
                echo "<a href='index.php'>返回</a>";
            }
        } else {
            echo "<script>alert('两次密码不一致！');</script>";
            echo "两次密码不一致！<br/>";
            echo "<a href='newpassword.php?id=user'>返回</a>";
        }
    } else {
        echo "<script>alert('原始密码错误!');</script>";
        echo "原始密码错误！<br/>";
        echo "<a href='newpassword.php?id=user'>返回</a>";
    }
}
?>