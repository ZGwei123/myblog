<?php
require_once 'base.php';
?>
<?php

if (! isset($_SESSION)) {
    session_start();
}
if (! isset($_SESSION['userName'])) {
    header("location:login.php");
}
require_once '../dbconfig.php';
$query = "SELECT * FROM select_question WHERE subject='php'";
$result = mysql_query($query);
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper">
	<div id="page-inner">
		<div class="row"> 
			<div class="col-md-12">
				<h2>生成试卷（组卷）</h2>
			</div>
		</div>
		<!-- /. ROW  -->
		<hr />
		<div class="row">
			<div class="col-md-10">
				<!-- Advanced Tables -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<i class="fa fa-paint-brush fa-2x"></i>录入试卷参数
					</div>
					<div class="panel-body">
						<form role="form" action="addpaperdo.php" method='post'>
							<div class="table-responsive">
								<div class="form-group input-group">
									&nbsp;<i class="fa fa-tasks">&nbsp;选择科目:</i>&nbsp; <input
										type="radio" name='subject' value="php">php&nbsp;&nbsp; <input
										type="radio" name="subject" value="java">java&nbsp;&nbsp; <input
										type="radio" name="subject" value="android">android
								</div>
								<div class="form-group input-group">
									<span class="input-group-addon"><i class="fa fa-question"> 试卷名称</i></span>
									<input type="text" class="form-control" name='name'>
								</div>
								<div class="form-group input-group">
									<span class="input-group-addon"><i class="fa fa-cogs"> 题目数量</i></span>
									<input type="text" class="form-control" name='total'>
								</div>
								<div class="form-group input-group">
									<span class="input-group-addon"><i class="fa fa-pencil"> 备注</i></span>
									<input type="text" class="form-control" name='memo'>
								</div>
								<div class="form-group input-group">

								</div>
								<input type='submit' class="btn btn-success" value='保存' />
							</div>
						</form>
					</div>

				</div>
			</div>
			<!--End Advanced Tables -->
		</div>
	</div>

</div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="../assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="../assets/js/jquery.metisMenu.js"></script>
<!-- DATA TABLE SCRIPTS -->
<script src="../assets/js/dataTables/jquery.dataTables.js"></script>
<script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
<script>
		$(document).ready(function() {
			$('#dataTables-example').dataTable();
		});
	</script>
<!-- CUSTOM SCRIPTS -->
<script src="../assets/js/custom.js"></script>
</body>
</html>


