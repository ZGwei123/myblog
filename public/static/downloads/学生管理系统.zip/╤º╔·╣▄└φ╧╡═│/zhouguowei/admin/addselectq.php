<?php require_once 'base.php';?>
<?php

if (! isset ( $_SESSION )) {
	session_start ();
}
if (! isset ( $_SESSION ['userName'] )) {
	header ( "location:login.php" );
}
$userName = $_SESSION ['userName'];

?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper">
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<h2>编辑选择题</h2>
			</div>
		</div>
		<!-- /. ROW  -->
		<hr />
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<!-- class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1"> -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<strong><i class='fa fa-edit fa-2x'></i> 编辑选择题</strong><br/>
						<font color="red">(在多选框中勾选正确答案)</font>
					</div>
					<div class="panel-body">
						<form role="form" action="addselectqdo.php" method='post'>
							<br /> <input type='hidden' name='id' />
							<div class="form-group input-group">
								&nbsp;<i class="fa fa-tasks">&nbsp;选择科目:</i>&nbsp; <input type="radio" name='subject' value="php">php&nbsp;&nbsp; 
								<input type="radio" name="subject" value="java" >java&nbsp;&nbsp;
								<input type="radio" name="subject" value="android" >android
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-question"> 题目</i></span>
								<textarea rows="2" class="form-control" name='title'></textarea>
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-pencil">&nbsp; <input type="checkbox" name="select[]" value="1"> 选项1</i></span>
								<input type="text" class="form-control" name="option1"
									 /> 
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-pencil">&nbsp; <input type="checkbox" name="select[]" value="2"> 选项2</i></span>
								<input type="text" class="form-control" name="option2"
									 /> 
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-pencil">&nbsp; <input type="checkbox" name="select[]" value="3"> 选项3</i></span>
								<input type="text" class="form-control" name="option3"
									 /> 
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-pencil">&nbsp; <input type="checkbox" name="select[]" value="4"> 选项4</i></span>
								<input type="text" class="form-control" name="option4"
									 /> 
							</div>
							<input type='submit' class="btn btn-success" value='确认添加' />
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="../assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="../assets/js/jquery.metisMenu.js"></script>
<!-- DATA TABLE SCRIPTS -->
<script src="../assets/js/dataTables/jquery.dataTables.js"></script>
<script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
<script>
		$(document).ready(function() {
			$('#dataTables-example').dataTable();
		});
	</script>
<!-- CUSTOM SCRIPTS -->
<script src="../assets/js/custom.js"></script>

</body>
</html>
