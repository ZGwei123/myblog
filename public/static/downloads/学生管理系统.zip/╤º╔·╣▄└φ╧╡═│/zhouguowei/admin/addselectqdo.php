<?php
header("content-type:text/html;charset=utf-8");
if (! isset($_SESSION)) {
    session_start();
}
if (! isset($_SESSION['userName'])) {
    header('location:login.php');
}
$subject = $_REQUEST['subject'];
$title = $_REQUEST['title'];
$select=$_REQUEST['select'];
if(count($select)>1){
    $type="多";
} else {
    $type="单";
}
$option = array(
    $_REQUEST['option1'],
    $_REQUEST['option2'],
    $_REQUEST['option3'],
    $_REQUEST['option4']
);
require_once '../dbconfig.php';
$query1 = "INSERT INTO select_question VALUES(NULL,'$subject','$type','$title',null)";
$query2 = "SELECT * FROM select_question WHERE subject='$subject' AND type='$type' AND title='$title'";
if (mysql_query($query1)) {
    $result1 = mysql_query($query2);
    $row = mysql_fetch_array($result1);
    $id = $row['id'];
    $sign=1;
    foreach ($option as $value) {
        $isanswer=0;
        for($i=0;$i<count($select);$i++){
            if($select[$i]==$sign){
                $isanswer=1;
                break;
            }
        }
        $query3 = "INSERT INTO select_item VALUES(NULL,$id,$isanswer,'$value',null)";
        $result2 = mysql_query($query3);
        $sign++;
    }
    header('location:selectq.php');
} else {
    echo "题目添加失败！<br/>";
    echo "<a href='addselectq.php'>返回</a>";
}
?>
