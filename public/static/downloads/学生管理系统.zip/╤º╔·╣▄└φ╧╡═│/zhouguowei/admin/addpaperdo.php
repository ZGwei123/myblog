<?php
header("content-type:text/html;charset=utf-8");
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['userName'])){
    header('location:login.php');
}
require_once '../dbconfig.php';
$name=$_REQUEST['name'];
$subject=$_REQUEST['subject'];
$total=$_REQUEST['total'];  
$memo=$_REQUEST['memo'];
$query1="SELECT * FROM select_question WHERE subject='$subject'";
$result1=mysql_query($query1);
for($i=0;$row1=mysql_fetch_array($result1);$i++){
    $questionid[$i]=$row1['id'];
}
shuffle($questionid);
$questionid1=array_slice($questionid,0,$total);
$content=$questionid1[0];
for($i=1;$i<count($questionid1);$i++){
    $content.=",".$questionid1[$i];
}
$query="INSERT INTO paper VALUES(null,'$name','$subject',".count($questionid1).",'$content','$memo')";
$result=mysql_query($query);
if($result){
    header('location:paper.php');
} else {
    echo "生成试卷失败！<br/>";
    echo "<a href='addpaper.php'>返回</a>";
}
?>