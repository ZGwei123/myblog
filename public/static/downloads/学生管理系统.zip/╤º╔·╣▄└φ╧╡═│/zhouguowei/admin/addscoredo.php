<?php
header("content-type:text/html;charset=utf-8");
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['userName'])){
    header('location:login.php');
}
$studentId=$_REQUEST['studentId'];
$test_name=$_REQUEST['test_name'];
$subject=$_REQUEST['subject'];
$mark=$_REQUEST['mark'];
require_once '../dbconfig.php';
$query1=mysql_query("SELECT * FROM paper WHERE name='".$test_name."' AND subject='".$subject."'");
$row=mysql_fetch_array($query1);
$query="INSERT INTO score VALUES(NULL,'$studentId','$test_name','$subject',".$row['id'].",'$mark')";
if(mysql_query($query)){
    header("location:score.php");
} else {
    echo '<script>alert("添加失败！");</script>';
    echo '<a href="addscore.php">重新添加</a>';
}
?>