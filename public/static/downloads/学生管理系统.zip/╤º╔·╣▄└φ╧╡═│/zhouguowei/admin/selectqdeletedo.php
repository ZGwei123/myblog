<?php
header ( "content-type:text/html;charset=utf-8" );
if (! isset ( $_SESSION )) {
	session_start ();
}
if (! isset ( $_SESSION['userName'] )) {
	header ( "location:login.php" );
} else {
	$id = $_REQUEST['id'];
	require_once '../dbconfig.php';
	// 删除语句
	$sql1 = "delete from select_question where id='$id'";
	$sql2 = "delete from select_item where select_question_id=$id";
	//exit($sql);
	$result = mysql_query ( $sql2, $conn );
	if ($result) {
	    if(mysql_query($sql1)){
	        header('location:selectq.php');
	    } else {
	        echo "<script>alert('题目删除失败！');</script>";
	        echo "<a href='selectq.php'>返回</a>";
	    }
	} else {
		echo "<script>alert('选项删除失败!');</script>";
		echo "<a href='selectq.php'>返回</a>";
	}
}
?>
