<?php
require_once '../dbconfig.php';
header ( "content-type:text/html;charset=utf-8" );

// 取表单数据
$id = $_REQUEST ['id'];
$subject = $_REQUEST ['subject'];
$title = $_REQUEST ['title'];
$option=array($_REQUEST['option1'],$_REQUEST['option2'],$_REQUEST['option3'],$_REQUEST['option4']);
$select=$_REQUEST['select'];
if(count($select)>1){
    $type="多";
} else {
    $type="单";
}

// sql语句中字符串数据类型都要加引号，数字字段随便
$sql2="SELECT * FROM select_item WHERE select_question_id=$id";
$result2 = mysql_query($sql2);
for($i=0;$i<4;$i++){
    $row2 = mysql_fetch_array($result2);
    $content[$i]=$row2['content'];
}
for($i=0;$i<4;$i++){
    $result1=mysql_query("UPDATE select_item SET content='$option[$i]',isanswer=0 where select_question_id=$id AND content='$content[$i]'");
    if(!$result1){
        echo '选项内容修改失败！';
        echo "<a href='selectqedit.php'>返回</a>";
    }
}
for($i=0;$i<count($select);$i++){
    $result4=mysql_query("UPDATE select_item SET isanswer=1 WHERE id=$select[$i]");
    if(!$result4){
        echo "答案选项修改失败!";
        echo "<a href='selectqedit.php'>返回</a>";
    }
}
        $sql = "UPDATE select_question SET subject='$subject',type='$type',title='$title' WHERE id=$id";
        if(mysql_query($sql)){
            header('location:selectq.php');
        } else {
            echo "题目修改失败！";
            echo "<a href='selectqedit.php'>返回</a>";
        }