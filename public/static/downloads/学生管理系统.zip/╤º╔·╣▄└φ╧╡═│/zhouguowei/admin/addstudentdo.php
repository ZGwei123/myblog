<?php
header("content-type:text/html;charset=utf-8");
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['userName'])){
    header('location:login.php');
}
$studentId=$_REQUEST['studentId'];
$name=$_REQUEST['name'];
$className=$_REQUEST['className'];
$birthday=$_REQUEST['birthday'];
$sex=$_REQUEST['sex'];
$nation=$_REQUEST['nation'];
require_once '../dbconfig.php';
$query="INSERT INTO student VALUES(NULL,'$studentId','$name','$className','$birthday','$sex','$nation','81fe8bfe87576c3ecb22426f8e57847382917acf')";
if(mysql_query($query)){
    header("location:index.php");
} else {
    echo '<script>alert("添加失败！");</script>';
    echo '<a href="addstudent.php">重新添加</a>';
}
?>