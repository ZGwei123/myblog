<?php require_once 'base.php';?>
<?php

if (! isset ( $_SESSION )) {
	session_start ();
}
if (! isset ( $_SESSION ['userName'] )) {
	header ( "location:login.php" );
}

?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper">
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<h2>添加成绩信息</h2>
			</div>
		</div>
		<!-- /. ROW  -->
		<hr />
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<!-- class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1"> -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<strong><i class='fa fa-edit fa-2x'></i> 填写成绩信息 </strong>
					</div>
					<div class="panel-body">
						<form role="form" action="addscoredo.php" method='post'>
							<br /> <input type='hidden' name='id' />
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-circle-o-notch">
										学号</i></span> <input type="text" class="form-control"
									 name='studentId'
									 />
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-calendar"> 试卷名</i></span>
								<input type="text" class="form-control" 
									name='test_name'  />
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-tasks"> 科目</i></span>
								<select class="form-control" name='subject'>
								    <option value="java">java</option>
								    <option value="php">php</option>
								    <option value="android">android</option>
								</select>
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-calendar-o"> 成绩</i></span>
								<input type="text" class="form-control"
									id='birthday' name='mark'  />
							</div>
							
							<input type='submit' class="btn btn-success" value='确认添加' />
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="../assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="../assets/js/jquery.metisMenu.js"></script>
<!-- DATA TABLE SCRIPTS -->
<script src="../assets/js/dataTables/jquery.dataTables.js"></script>
<script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
<script>
		$(document).ready(function() {
			$('#dataTables-example').dataTable();
		});
	</script>
<!-- CUSTOM SCRIPTS -->
<script src="../assets/js/custom.js"></script>
</body>
</html>

