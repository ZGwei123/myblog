<?php
header("content-type:text/html;charset=utf-8");
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['userName'])){
    header('location:login.php');
}
$id=$_REQUEST['id'];
require_once '../dbconfig.php';
$query="DELETE FROM paper WHERE id=$id";
$result=mysql_query($query);
if($result){
    header('location:paper.php');
} else {
    echo "删除失败！<br/>";
    echo "<a href='paper.php'>返回</a>";
}
?>