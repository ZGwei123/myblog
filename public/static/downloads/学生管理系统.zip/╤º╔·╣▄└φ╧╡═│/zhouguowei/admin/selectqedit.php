<?php require_once 'base.php';?>
<?php

if (! isset ( $_SESSION )) {
	session_start ();
}
if (! isset ( $_SESSION ['userName'] )) {
	header ( "location:login.php" );
}
$userName = $_SESSION ['userName'];

require_once '../dbconfig.php';
// 访问student中指定的id
$id1 = $_REQUEST ['id'];
$query1 = "select * from select_question where id=$id1";
$result1 = mysql_query ( $query1 );
$row1 = mysql_fetch_array ( $result1 );
$query2 = "select * from select_item where select_question_id=$id1";
$result2 = mysql_query ( $query2 );
for($i = 1; $i <= 4; $i ++) {
	$row2 = mysql_fetch_array ( $result2 );
	$option [$i] = $row2 ['content'];
	$id [$i] = $row2['id'];
	$select[$i]=$row2['isanswer'];
}
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper">
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<h2>编辑选择题</h2>
			</div>
		</div>
		<!-- /. ROW  -->
		<hr />
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<!-- class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1"> -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<strong><i class='fa fa-edit fa-2x'></i> 编辑选择题</strong><br/>
						<font color="red">(在多选框中勾选正确答案)</font>
					</div>
					<div class="panel-body">
						<form role="form" action="selectqeditdo.php" method='post'>
							<br /> <input type='hidden' name='id' value='<?=$row1 ['id']?>' />
							<div class="form-group input-group">
								&nbsp;<i class="fa fa-tasks">&nbsp;选择科目:</i>&nbsp; <input type="radio" name='subject' value="php" <?=$row1['subject']=="php"?"checked":"" ?>>php&nbsp;&nbsp; 
								<input type="radio" name="subject" value="java" <?=$row1['subject']=="java"?"checked":""?>>java&nbsp;&nbsp;
								<input type="radio" name="subject" value="android" <?=$row1['subject']=="android"?"checked":""?>>android
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-question"> 题目</i></span>
								<textarea rows="2" class="form-control" name='title'><?=$row1 ['title']?></textarea>
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa 	fa-pencil">&nbsp; <input type="checkbox" name="select[]" value="<?=$id['1']?>" <?=$select['1']==1?"checked":""?>> 选项1</i></span>
								<input type="text" class="form-control" name="option1"
									value="<?=$option['1']?>" /> 
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa 	fa-pencil">&nbsp; <input type="checkbox" name="select[]" value="<?=$id['2']?>" <?=$select['2']==1?"checked":""?>> 选项2</i></span>
								<input type="text" class="form-control" name="option2"
									value="<?=$option['2']?>" /> 
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa 	fa-pencil">&nbsp; <input type="checkbox" name="select[]" value="<?=$id['3']?>" <?=$select['3']==1?"checked":""?>> 选项3</i></span>
								<input type="text" class="form-control" name="option3"
									value="<?=$option['3']?>" /> 
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa 	fa-pencil">&nbsp; <input type="checkbox" name="select[]" value="<?=$id['4']?>" <?=$select['4']==1?"checked":""?>> 选项4</i></span>
								<input type="text" class="form-control" name="option4"
									value="<?=$option['4']?>" /> 
							</div>
							<input type='submit' class="btn btn-success" value='确认修改' />
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="../assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="../assets/js/jquery.metisMenu.js"></script>
<!-- DATA TABLE SCRIPTS -->
<script src="../assets/js/dataTables/jquery.dataTables.js"></script>
<script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
<script>
		$(document).ready(function() {
			$('#dataTables-example').dataTable();
		});
	</script>
<!-- CUSTOM SCRIPTS -->
<script src="../assets/js/custom.js"></script>

</body>
</html>
