<?php
require_once '../dbconfig.php';
header ( "content-type:text/html;charset=utf-8" );

// 取表单数据
$id = $_REQUEST ['id'];
$studentId = $_REQUEST ['studentId'];
$test_name = $_REQUEST ['test_name'];
$subject = $_REQUEST ['subject'];
$mark = $_REQUEST ['mark'];

// sql语句中字符串数据类型都要加引号，数字字段随便
$query=mysql_query("SELECT * FROM paper WHERE name='".$test_name."' AND subject='".$subject."'");
$row=mysql_fetch_array($query);
$sql = "UPDATE score SET studentId='$studentId',test_name='$test_name',subject='$subject',mark='$mark',paper_id=".$row['id']." WHERE id=$id";
if (mysql_query ( $sql )) {
	header("location:score.php");
} else {
	echo "修改失败！！！<br/>";
	echo "<a href='scoreedit.php?id=$id'>返回</a>";
}


