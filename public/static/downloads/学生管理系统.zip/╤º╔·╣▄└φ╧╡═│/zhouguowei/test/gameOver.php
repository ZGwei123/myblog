<?php
//计算分数
header("content-type:text/html;charset=utf-8");
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['studentId'])){
    header("location:login.php");
}
$paper_id=$_REQUEST['paper_id'];
require_once '../dbconfig.php';
$sql="SELECT * FROM answer_paper WHERE studentid='".$_SESSION['studentId']."' AND paper_id=".$paper_id;
$result=mysql_query($sql);
while($answer=mysql_fetch_array($result)){
    $testanswer[]=$answer;
}
foreach($testanswer as $key=>$answer1){
    $seanswer[$answer1['select_question_id']]=$answer1['answer'];
    $sql1="SELECT select_question.type,select_item.id,select_item.select_question_id,select_item.isanswer
        FROM select_item INNER JOIN select_question WHERE select_item.select_question_id=select_question.id 
        AND select_question_id=".$answer1['select_question_id'];
    $result1=mysql_query($sql1);
    while($row1=mysql_fetch_array($result1)){
        $tanswer[]=$row1;
    }
    foreach($tanswer as $tanswer1){
        if($tanswer1['isanswer']==1){
            $isanswer[$tanswer1['id']]=1;
        }
        $question_type[$tanswer1['select_question_id']]=$tanswer1['type'];
    }
    $trueanswer[$answer1['select_question_id']]=serialize($isanswer);
    $tanswer=null;
    $isanswer=null;
}
foreach($seanswer as $key=>$value){
    $array_answer=unserialize($value);
    if(is_array($array_answer)){
    foreach($array_answer as $item_id=>$isitem){
        if($isitem==1){
            $ianswer[$item_id]=$isitem;
        }
    }
    ksort($ianswer);
    $seanswer[$key]=serialize($ianswer);
    }
    $ianswer=null;
}
$number=0;
foreach($seanswer as $id=>$test_isanswer){
    if($test_isanswer!=""){
        if($question_type[$id]=="单"){
            if($test_isanswer==$trueanswer[$id]){
                $number++;
            } else {
                $false_question[$id]=$trueanswer[$id];
            }
        } else {
            if($test_isanswer==$trueanswer[$id]){
                $number=$number+2;
            } else {
                $false_question[$id]=$trueanswer[$id];
            }
        }
    } else {
        $false_question[$id]=$trueanswer[$id];
    }
}
    $sql6="SELECT * FROM score WHERE studentId='".$_SESSION['studentId']."' AND paper_id=".$paper_id;
    $result6=mysql_query($sql6);
    $row6=mysql_fetch_array($result6);
if(!$row6){
    $sql2="SELECT * FROM paper WHERE id=".$paper_id;
    $result2=mysql_query($sql2);
    $paper_message=mysql_fetch_array($result2);
    $sql3="INSERT INTO score VALUES(null,'".$_SESSION['studentId']."','".
        $paper_message['name']."','".$paper_message['subject']."',".$paper_id.",".$number.")";
    mysql_query($sql3);
} else {
    echo "<script>alert('该课成绩已存在，此次作答不记录分数！');</script>";
}

//显示出选择错误的题目的正确答案
foreach($false_question as $question_id=>$item){
    $sql4="SELECT * FROM select_question WHERE id=".$question_id;

    $result4=mysql_query($sql4);
    $title=mysql_fetch_array($result4);
    $content="";
    foreach(unserialize($item) as $select_item=>$value1){
        $sql5="SELECT * FROM select_item WHERE id=".$select_item;
        $result5=mysql_query($sql5);
        $item_content=mysql_fetch_array($result5);
        $content.=($item_content['content']."<br/>");
    }
    $analysis[$title['title']]=$content;
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>在线练习系统</title>
<!-- BOOTSTRAP STYLES-->
<link href="../assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="../assets/css/font-awesome.css" rel="stylesheet" />
<!-- MORRIS CHART STYLES-->
<link href="../assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
<!-- CUSTOM STYLES-->
<link href="../assets/css/custom.css" rel="stylesheet" />
<!-- GOOGLE FONTS-->
<!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans'
    rel='stylesheet' type='text/css' /> -->
<script type="text/javascript" src="../js/laydate.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-default navbar-cls-top " role="navigation"
        style="margin-bottom: 0">
        <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse"
            data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span> <span
            class="icon-bar"></span> <span class="icon-bar"></span> <span
            class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="listtest.php">在线练习系统</a>
            </div>
            <div
            style="color: white; padding: 15px 50px 5px 50px; float: right; font-size: 16px;">
            学号：<?php echo $_SESSION['studentId'];?>&nbsp;姓名：<?php echo $_SESSION['name']; ?>&nbsp;&nbsp;
            <a href="listtest.php" class="btn btn-danger square-btn-adjust">退&nbsp;出</a>
			</div>
		</nav>
<!-- /. NAV SIDE  -->
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<h2>总分：<?=$number ?> 分 , 以下是错选题的正确答案：</h2>
			</div>
		</div>
		<!-- /. ROW  -->
		<hr />
		<div class="row">
			<div class="col-md-12">
				<!-- Advanced Tables -->
				<div class="panel panel-default">
					<div class="panel-heading"></div>
					<div class="panel-body">
						<div class="table-responsive">
							
				                <?php 
				                    foreach($analysis as $key2=>$value2){?>
				                   <p><?=$key2?></p>
				                    <p><?=$value2 ?></p>
				                    <hr />
				                <?php }?>
						</div>

					</div>
				</div>
				<!--End Advanced Tables -->
			</div>
		</div>

	</div>

<!-- /. PAGE INNER  -->

<!-- /. PAGE WRAPPER  -->
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="../assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="../assets/js/jquery.metisMenu.js"></script>
<!-- DATA TABLE SCRIPTS -->
<script src="../assets/js/dataTables/jquery.dataTables.js"></script>
<script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
<script>
		$(document).ready(function() {
			$('#dataTables-example').dataTable();
		});
	</script>
<!-- CUSTOM SCRIPTS -->
<script src="../assets/js/custom.js"></script>
</body>
</html>

    