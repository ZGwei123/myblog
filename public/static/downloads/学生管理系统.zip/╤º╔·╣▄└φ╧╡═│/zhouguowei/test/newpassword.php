<?php
header("content-type:text/html;charset=utf-8");
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['studentId'])){
    header("location:login.php");
}
if(isset($_REQUEST['oldpassword'])){
    require_once '../dbconfig.php';
    $oldpassword=sha1($_REQUEST['oldpassword']);
    $password=sha1($_REQUEST['password']);
    $password1=sha1($_REQUEST['password1']);
    $sql="SELECT * FROM student WHERE studentId='".$_SESSION['studentId']."'";
    $result=mysql_query($sql);
    $row=mysql_fetch_array($result);
    if($row['password']==$oldpassword){
        if($password==$password1){
            $sql1="UPDATE student SET password='".$password."' WHERE studentId='".$_SESSION['studentId']."'";
            if(mysql_query($sql1)){
                header("location:loginout.php");
            } else {
                echo "<script>alert('密码修改失败！')</script>";
            }
        } else {
            echo "<script>alert('两次输入的密码不一致！');</script>";
        }
    } else {
        echo "<script>alert('原密码错误！');</script>";
    }
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>修改密码</title>
<!-- BOOTSTRAP STYLES-->
<link href="../assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="../assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLES-->
<link href="../assets/css/custom.css" rel="stylesheet" />
<!-- GOOGLE FONTS-->
<!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans'
	rel='stylesheet' type='text/css' /> -->
</head>
<body>
	<div class="container">
		<div class="row text-center ">
			<div class="col-md-12">
				<br /> <br />
				<h2>修改密码</h2>
				<h5>(授权访问)</h5>
				<br />
			</div>
		</div>
		<div class="row ">
			<div
				class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
				<div class="panel panel-default">
					<div class="panel-heading">
						<strong> 请输入修改信息 </strong>
					</div>
					<div class="panel-body">
						<form role="form" action='newpassword' method='post'>
							<br />
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" class="form-control"
									placeholder="在此输入原始密码" name='oldpassword' />
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" class="form-control"
									placeholder="在此输入新密码" name='password' />
							</div>
							<div class="form-group input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" class="form-control"
									placeholder="在此重复输入新密码" name='password1' />
							</div>
							<input type='submit' class="btn btn-primary " value='确认修改' />
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
	<!-- JQUERY SCRIPTS -->
	<script src="../assets/js/jquery-1.10.2.js"></script>
	<!-- BOOTSTRAP SCRIPTS -->
	<script src="../assets/js/bootstrap.min.js"></script>
	<!-- METISMENU SCRIPTS -->
	<script src="../assets/js/jquery.metisMenu.js"></script>
	<!-- CUSTOM SCRIPTS -->
	<script src="../assets/js/custom.js"></script>

</body>
</html>
