<?php
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['studentId'])){
    header("location:login.php");
}
 $paper_id=$_REQUEST['paperId'];
 $item_id=$_REQUEST['itemid'];
 $question_type=$_REQUEST['type'];
 $question_id=$_REQUEST['selectQuestionId'];
 $is_answer=$_REQUEST['selectStatus']==true?1:0;
require_once '../dbconfig.php';
 $sql="SELECT * FROM answer_paper WHERE studentid='".$_SESSION['studentId']."' AND paper_id=".
     $paper_id." AND select_question_id=".$question_id;
 $result=mysql_query($sql);
 $answer=mysql_fetch_array($result);
 $oldanswer=unserialize($answer);
 if($question_type=='单'){
     if(is_array($oldanswer)){
        foreach($oldanswer as $id=>$value){
             $oldanswer[$id]=0;
        }
     }
     $oldanswer[$item_id]=1;
 } else {
     $oldanswer[$item_id]=$is_answer;
 }
 $newanswer=serialize($oldanswer);
 $sql1="UPDATE answer_paper SET answer='".$newanswer."' WHERE studentid='".$_SESSION['studentId'].
 "' AND paper_id=".$paper_id." AND select_question_id=".$question_id;
 mysql_query($sql1);
 $data = array(
     'selectQuestionId' => $_REQUEST['selectQuestionId']
 );
 echo json_encode($data);
?>