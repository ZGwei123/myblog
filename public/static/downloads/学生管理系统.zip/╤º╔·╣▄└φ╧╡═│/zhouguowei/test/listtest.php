<?php 
	if(!isset($_SESSION)){
		session_start();
	}
	if(!isset($_SESSION['studentId'])){
	    header("location:login.php");
	}
	$studentId=$_SESSION['studentId'];
	require_once '../dbconfig.php';
	$sql1="SELECT * FROM student WHERE studentId='".$studentId."'";
	$result1=mysql_query($sql1);
	$row1=mysql_fetch_array($result1);
	$sql2="SELECT paper.id,paper.name,paper.subject,score.mark FROM paper LEFT JOIN score ON score.studentId='".$studentId."' AND paper.id=score.paper_id";
    $result2=mysql_query($sql2);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>在线练习系统</title>
<!-- BOOTSTRAP STYLES-->
<link href="../assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="../assets/css/font-awesome.css" rel="stylesheet" />
<!-- MORRIS CHART STYLES-->
<link href="../assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
<!-- CUSTOM STYLES-->
<link href="../assets/css/custom.css" rel="stylesheet" />
<!-- GOOGLE FONTS-->
<!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans'
    rel='stylesheet' type='text/css' /> -->
<script type="text/javascript" src="../js/laydate.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-default navbar-cls-top " role="navigation"
        style="margin-bottom: 0">
        <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse"
            data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span> <span
            class="icon-bar"></span> <span class="icon-bar"></span> <span
            class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="listtest.php">在线练习系统</a>
            </div>
            <div
            style="color: white; padding: 15px 50px 5px 50px; float: right; font-size: 16px;">
            考生名：<?=$row1['name']?>&nbsp;&nbsp;<a href='newpassword.php'>修改密码</a>&nbsp;<a href="../index.php"
					class="btn btn-danger square-btn-adjust">首页</a>&nbsp;<a href="loginout.php"
					class="btn btn-danger square-btn-adjust">退出登录</a>
			</div>
		</nav>
<!-- /. NAV SIDE  -->
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<h2>我的考试</h2>
			</div>
		</div>
		<!-- /. ROW  -->
		<hr />
		<div class="row">
			<div class="col-md-12">
				<!-- Advanced Tables -->
				<div class="panel panel-default">
					<div class="panel-heading"></div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover"
								id="dataTables-example">
								<thead>
									<tr>
										<th>序号</th>
										<th>考试编号</th>
										<th>考试名称</th>
										<th>科目</th>
										<th>成绩</th>
										<th>操作</th>
									</tr>
								</thead>
								<tbody>
                        		<?php
                        $line = 0;
                        while ($row2 = mysql_fetch_array($result2)) {
                            $line ++;
                            $linecolor = $line % 2 == 0 ? 'odd gradeX' : 'even gradeC';
                            echo "<tr class='$linecolor'>";
                            echo "<td>" . $line . "</td>";
                            echo "<td>" . $row2['id'] . "</td>";
                            echo "<td>" . $row2['name'] . "</td>";
                            echo "<td>" . $row2['subject'] . "</td>";
                            if($row2['mark']==null){
                                echo "<td><font color='red'><b>待考</b></font></td>";
                            } else {
                                echo "<td>" . $row2['mark'] . "</td>";
                            }
                            $url="&nbsp;<a href='test?paper_id=".$row2['id']."' class='btn btn-danger btn-sm shiny'><i class='fa fa-edit fa-x'></i> 现在考试</a>";
                            echo "<td>" . ($row2['mark']==null?$url:"") . "</td>";
                            echo "</tr>";
                        }
                        ?>
								</tbody>
							</table>
						</div>

					</div>
				</div>
				<!--End Advanced Tables -->
			</div>
		</div>

	</div>

<!-- /. PAGE INNER  -->

<!-- /. PAGE WRAPPER  -->
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="../assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="../assets/js/jquery.metisMenu.js"></script>
<!-- DATA TABLE SCRIPTS -->
<script src="../assets/js/dataTables/jquery.dataTables.js"></script>
<script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
<script>
		$(document).ready(function() {
			$('#dataTables-example').dataTable();
		});
	</script>
<!-- CUSTOM SCRIPTS -->
<script src="../assets/js/custom.js"></script>
</body>
</html>

    