<?php 
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['studentId'])){
    header("location:login.php");
}

$studentId=$_SESSION['studentId'];
$name=$_SESSION['name'];
$paper_id=$_REQUEST['paper_id'];
require_once '../dbconfig.php';
$sql1="SELECT * FROM paper WHERE id=".$paper_id;
$result1=mysql_query($sql1);
$row1=mysql_fetch_array($result1);
$select_question_id=explode(",",$row1['content']);
$sql="SELECT * FROM answer_paper WHERE studentid='".$studentId."' AND paper_id=".$paper_id;
$result=mysql_query($sql);
if(!mysql_fetch_array($result)){
    foreach($select_question_id as $no){
        $sql3="INSERT INTO answer_paper values(null,'".$studentId."',".$paper_id.",".$no.",'',null)";
        mysql_query($sql3);
    }
}
$sql4="SELECT type,title,select_question_id,answer FROM select_question INNER JOIN answer_paper WHERE select_question.id=answer_paper.select_question_id AND 
answer_paper.studentid='".$studentId."' AND answer_paper.paper_id=".$paper_id;
$re=mysql_query($sql4);
while($result4=mysql_fetch_array($re)){
    $answer_paper[]=$result4;
}
for($i=0;$i<count($answer_paper);$i++){
    $answer_paper[$i]['answer']=unserialize($answer_paper[$i]['answer']);
    $sql5="SELECT * FROM select_item WHERE select_question_id=".$answer_paper[$i]['select_question_id'];
    $result5=mysql_query($sql5);
    $question_answer=null;
    while($items=mysql_fetch_array($result5)){
        $question_answer[]=$items;
    }
    $answer_paper[$i]['items']=$question_answer;
}

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>在线练习系统</title>
<!-- BOOTSTRAP STYLES-->
<link href="../assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="../assets/css/font-awesome.css" rel="stylesheet" />
<!-- MORRIS CHART STYLES-->
<link href="../assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
<!-- CUSTOM STYLES-->
<link href="../assets/css/custom.css" rel="stylesheet" />
<!-- GOOGLE FONTS-->
<!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans'
    rel='stylesheet' type='text/css' /> -->
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/laydate.js"></script>
<script language="javascript">
	function ajaxsubmit(itemid,type) {
		var selectItem = document.getElementById(itemid);
		var selectStatus = selectItem.checked;
		var selectQuestionId = selectItem.value;
		var paperId = document.getElementById('paperId').value;
		var data = {
			"paperId":paperId,
			"type":type,
			"itemid" : itemid,
			"selectQuestionId":selectQuestionId,
			"selectStatus" : selectStatus
		};
		var targetAddress = "insertOperate.php?"+Math.random();
		$.ajax({
			url :targetAddress, //后台处理程序  
			type : 'post', //数据传送方式  
			dataType : 'json', //接受数据格式  
			data : data, //要传送的数据  
			success : update_page
		//回传函数(这里是函数名字)
		});
	}
	//回传函数实体，参数为XMLhttpRequest.responseText 
	function update_page(json) { 
 		var str = "<i class='fa fa-check'></i>";
		var selectQuestionId = json.selectQuestionId;
		document.getElementById("sign" + selectQuestionId).innerHTML = str;
	}
</script>
    </head>
    <body>
    <nav class="navbar navbar-default navbar-cls-top " role="navigation"
        style="margin-bottom: 0">
        <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse"
            data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span> <span
            class="icon-bar"></span> <span class="icon-bar"></span> <span
            class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="test.php">在线练习系统</a>
            </div>
            <div
            style="color: white; padding: 15px 50px 5px 50px; float: right; font-size: 16px;">
            学号：<?=$studentId?>&nbsp;姓名：<?=$name ?>&nbsp;&nbsp;<a href="gameOver.php?paper_id=<?=$paper_id?>" class="btn btn-danger square-btn-adjust">交&nbsp;卷</a>
			</div>
		</nav>
<!-- /. NAV SIDE  -->
		<div id="page-inner">
			<div class="row">
				<div class="col-md-11" align='center'>
					<h2><?=$row1['name']?></h2>
				</div>
			</div>
			<!-- --------------------------------------------------------------------------- -->
			<input type='hidden' name='paperId' id='paperId'
				value='<?=$paper_id?>' />
			<!--试题内容行-->
            <?php foreach($answer_paper as $row=>$value){?>
			<hr />
			<div class="row">
				<div class="col-md-12 col-sm-4">
					<div class="panel panel-success">
						<div class="panel-heading">
							<table border=0 cellpadding='10' cellspacing='10'>
								<tr>
									<td width='30'><div id='sign<?=$value['select_question_id']?>'>
											<i class="fa fa-tag"></i>
										</div></td>
									<td width='20'><?=$row+1?>、</td>
									<td><?=$value['title']?></td>
								</tr>
							</table>
						</div>
						<div class="panel-body">
							<div class="form-group">
								<form action="#">
								    <?php foreach($value['items'] as $index=>$item){?>
									<div class="checkbox">
										<label>
										      <input type="<?=$value['type']=='单'?'radio':'checkbox' ?>"
										       name="<?=$value['select_question_id'] ?>" 
										       id="<?=$item['id'] ?>"
										       value="<?=$value['select_question_id'] ?>"
										       onchange="ajaxsubmit(<?=$item['id']?>,'<?=$value['type']?>')"
										       <?=isset($value['answer'][$item['id']]) && $value['answer'][$item['id']]==1?'checked':'' ?>
										      >
										      <?php
										          switch($index){
										              case 0:
										                 echo "A、";
										                 break;
										              case 1:
										                  echo "B、";
										                  break;
										              case 2:
										                  echo "C、";
										                  break;
										              case 3:
										                  echo "D、";
										                  break;
										          }
										          echo $item['content'];
										      ?>
										</label>
									</div>
									<?php }?>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php }?>
			<!--试题内容行-->
			<!-- -------------------------------------------------------------------------- -->
		</div>

</body>
</html>
		