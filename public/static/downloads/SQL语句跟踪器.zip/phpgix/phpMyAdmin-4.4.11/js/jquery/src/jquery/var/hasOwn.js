define([
	"./class2type"
], function( class2type ) {
	return class2type.hasOwnProperty;
});
